"use client";

import React, { useEffect, useState } from "react";
import { CheckCircle2, Clock } from "lucide-react";

import { GlassCard } from "@/components/GlassCard";
import ClientTrackerDashboard from "@/components/client/ClientTrackerDashboard";
import { dashboardAPI } from "@/services/api";

interface AthleteData {
  todayTraining: any[];

  steps?: number;
  stepGoal?: number;

  sleepHours?: number;
  sleepGoal?: number;

  hydration?: number;
  hydrationGoal?: number;

  workoutCompletion?: number;
  recovery?: number;

  calories?: number;
  workoutsThisWeek?: number;
}

export default function AthleteDashboard() {
  const [athleteData, setAthleteData] = useState<AthleteData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const fetchDashboard = async () => {
      try {
        const data = await dashboardAPI.getAthleteData();

        if (mounted) {
          setAthleteData(data);
        }
      } catch (error) {
        console.error("Failed to fetch athlete data:", error);

        /*
         * The tracker can still render while the backend metric endpoint
         * is being connected.
         *
         * This does NOT affect authentication.
         */
        if (mounted) {
          setAthleteData({
            todayTraining: [],
          });
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    fetchDashboard();

    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div
      className="container"
      style={{
        maxWidth: "1180px",
        paddingBottom: "60px",
      }}
    >
      {/* Header */}
      <div
        className="section-header"
        style={{
          marginBottom: "30px",
          alignItems: "flex-end",
        }}
      >
        <div>
          <div
            className="label-text"
            style={{
              color: "var(--text-secondary)",
              marginBottom: "7px",
              letterSpacing: "0.16em",
            }}
          >
            ATHLETE INTELLIGENCE
          </div>

          <h2
            className="animated-gradient-text"
            style={{
              fontSize: "30px",
              textTransform: "none",
              marginBottom: "8px",
            }}
          >
            Your daily pulse
          </h2>

          <span
            className="label-text"
            style={{
              color: "var(--text-secondary)",
              textTransform: "none",
            }}
          >
            Track movement, recovery and consistency without the noise.
          </span>
        </div>
      </div>

      {/* Tracker */}
      <ClientTrackerDashboard
        steps={athleteData?.steps}
        stepGoal={athleteData?.stepGoal}
        sleepHours={athleteData?.sleepHours}
        sleepGoal={athleteData?.sleepGoal}
        hydration={athleteData?.hydration}
        hydrationGoal={athleteData?.hydrationGoal}
        workoutCompletion={athleteData?.workoutCompletion}
        recovery={athleteData?.recovery}
        calories={athleteData?.calories}
        workoutsThisWeek={athleteData?.workoutsThisWeek}
      />

      {/* Today's training */}
      <div
        className="app-card fade-in"
        style={{
          marginTop: "24px",
        }}
      >
        <div
          className="section-header"
          style={{
            marginBottom: "18px",
          }}
        >
          <div>
            <h3
              style={{
                fontSize: "16px",
                marginBottom: "5px",
              }}
            >
              Today's training
            </h3>

            <span
              style={{
                fontSize: "11px",
                color: "var(--text-secondary)",
              }}
            >
              Your assigned sessions for today.
            </span>
          </div>
        </div>

        {isLoading ? (
          <div
            style={{
              padding: "30px",
              textAlign: "center",
              color: "var(--text-secondary)",
            }}
          >
            Loading training plan...
          </div>
        ) : !athleteData ||
          !athleteData.todayTraining ||
          athleteData.todayTraining.length === 0 ? (
          <div
            style={{
              padding: "24px",
              textAlign: "center",
              color: "var(--text-secondary)",
              borderRadius: "16px",
              background: "rgba(255,255,255,0.025)",
            }}
          >
            No training scheduled for today yet.
          </div>
        ) : (
          <div className="plan-cards-container">
            {athleteData.todayTraining.map((training: any) => (
              <GlassCard
                key={training.id}
                title={training.title}
                subtitle={training.subtitle}
                statusText={training.statusText}
                statusColor={training.statusColor}
                Icon={
                  training.statusText === "completed"
                    ? CheckCircle2
                    : Clock
                }
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}