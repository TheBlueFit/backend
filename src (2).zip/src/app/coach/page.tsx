"use client";

import React, { useEffect, useState } from "react";
import {
  Activity,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";

import { GlassCard } from "@/components/GlassCard";
import CoachTrackerDashboard from "@/components/coach/CoachTrackerDashboard";
import { dashboardAPI } from "@/services/api";

interface CoachDashboardData {
  stats: any[];
  recentActivity: any[];
}

/*
 * Read a metric from the backend response.
 *
 * IMPORTANT:
 * There is intentionally NO fallback value here.
 *
 * If the backend has not provided the metric yet, we return
 * undefined so the UI can correctly display "—" / "No data yet"
 * instead of showing fake test numbers.
 */
function getStat(
  stats: any[],
  names: string[]
): number | undefined {
  const match = stats?.find((item) => {
    const name = String(
      item?.name ??
        item?.title ??
        item?.label ??
        ""
    ).toLowerCase();

    return names.some((candidate) =>
      name.includes(candidate.toLowerCase())
    );
  });

  if (!match) {
    return undefined;
  }

  const value = Number(match.value);

  return Number.isFinite(value)
    ? value
    : undefined;
}

export default function CoachDashboard() {
  const [dashboardData, setDashboardData] =
    useState<CoachDashboardData | null>(null);

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const fetchDashboard = async () => {
      try {
        setIsLoading(true);

        const data = await dashboardAPI.getCoachData();

        if (!mounted) return;

        setDashboardData({
          stats: Array.isArray(data?.stats)
            ? data.stats
            : [],

          recentActivity: Array.isArray(
            data?.recentActivity
          )
            ? data.recentActivity
            : [],
        });
      } catch (error) {
        console.error(
          "Failed to fetch coach data:",
          error
        );

        if (!mounted) return;

        setDashboardData({
          stats: [],
          recentActivity: [],
        });
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    fetchDashboard();

    return () => {
      mounted = false;
    };
  }, []);

  const stats = dashboardData?.stats ?? [];

  /*
   * These values come ONLY from the backend.
   *
   * No demo/test numbers are inserted here.
   */
  const activeClients = getStat(
    stats,
    ["active clients"]
  );

  const workoutCompletion = getStat(
    stats,
    ["workout completion"]
  );

  const sleepConsistency = getStat(
    stats,
    ["sleep consistency"]
  );

  const hydration = getStat(
    stats,
    ["hydration"]
  );

  const adherence = getStat(
    stats,
    ["adherence"]
  );

  return (
    <div
      className="container"
      style={{
        maxWidth: "1180px",
        paddingBottom: "60px",
      }}
    >
      {/* =========================================================
          HEADER
         ========================================================= */}

      <div
        className="section-header"
        style={{
          marginBottom: "30px",
        }}
      >
        <div>
          <div
            className="label-text"
            style={{
              color: "var(--text-secondary)",
              marginBottom: "7px",
              letterSpacing: "0.16em",
            }}
          >
            COACH INTELLIGENCE
          </div>

          <h2
            className="animated-gradient-text"
            style={{
              fontSize: "30px",
              textTransform: "none",
              marginBottom: "8px",
            }}
          >
            Training pulse
          </h2>

          <span
            className="label-text"
            style={{
              color: "var(--text-secondary)",
              textTransform: "none",
            }}
          >
            A quick view of adherence, recovery and daily
            client activity.
          </span>
        </div>
      </div>

      {/* =========================================================
          LOADING
         ========================================================= */}

      {isLoading ? (
        <div
          className="app-card fade-in"
          style={{
            padding: "45px 20px",
            textAlign: "center",
            color: "var(--text-secondary)",
          }}
        >
          Loading coach metrics...
        </div>
      ) : (
        <>
          {/* =====================================================
              TRACKER DASHBOARD

              Undefined values are intentional.
              They mean the backend does not have that metric yet.
             ===================================================== */}

          <CoachTrackerDashboard
            activeClients={activeClients}
            workoutCompletion={workoutCompletion}
            sleepConsistency={sleepConsistency}
            hydration={hydration}
            adherence={adherence}
          />

          {/* =====================================================
              RECENT CLIENT ACTIVITY
             ===================================================== */}

          <section
            className="app-card fade-in"
            style={{
              marginTop: "28px",
            }}
          >
            <div
              className="section-header"
              style={{
                marginBottom: "18px",
              }}
            >
              <div>
                <h3
                  style={{
                    fontSize: "16px",
                    marginBottom: "5px",
                  }}
                >
                  Recent client activity
                </h3>

                <span
                  style={{
                    fontSize: "11px",
                    color: "var(--text-secondary)",
                  }}
                >
                  Recent actions across your training
                  roster.
                </span>
              </div>

              <Activity size={18} />
            </div>

            {dashboardData?.recentActivity?.length ? (
              <div className="plan-cards-container">
                {dashboardData.recentActivity.map(
                  (activity: any) => {
                    const completed =
                      String(activity.status ?? "")
                        .toLowerCase() === "completed";

                    return (
                      <GlassCard
                        key={activity.id}
                        title={
                          activity.client ??
                          "Client"
                        }
                        subtitle={
                          activity.action ??
                          ""
                        }
                        statusText={
                          activity.status ??
                          ""
                        }
                        statusColor={
                          completed
                            ? "green"
                            : "red"
                        }
                        Icon={
                          completed
                            ? CheckCircle2
                            : AlertCircle
                        }
                      />
                    );
                  }
                )}
              </div>
            ) : (
              <div
                style={{
                  padding: "32px 20px",
                  textAlign: "center",
                  color: "var(--text-secondary)",
                  borderRadius: "16px",
                  background:
                    "rgba(255,255,255,0.018)",
                  border:
                    "1px solid rgba(255,255,255,0.055)",
                }}
              >
                No recent client activity yet.
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}