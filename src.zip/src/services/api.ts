const API_BASE_URL = (
  process.env.NEXT_PUBLIC_API_URL ||
  'https://b9uueqjgbb.execute-api.us-east-1.amazonaws.com'
).replace(/\/$/, '');

export interface UserSession {
  PK: string;
  userCode: string;
  role: 'CLIENT' | 'COACH' | 'ADMIN';
  name: string;
  email?: string;
  coachId?: string;
  mustChangePassword?: boolean;
  onboardingCompleted?: boolean;
}

export interface CoachClient {
  id: string;
  PK?: string;
  name: string;
  email?: string;
  goal: string;
  primaryGoal?: string;
  plan?: string;
  adherence: number;
  compliance?: string;
  lastCheckIn: string;
  status: 'on-track' | 'needs-attention' | 'Active' | 'Needs Review' | string;
  age?: number;
  height?: number;
  weight?: number;
  activityLevel?: string;
  medicalNotes?: string;
  coachId?: string;
}

const SESSION_KEY = 'bluefit_user_session';

export const authSession = {
  get: (): UserSession | null => {
    if (typeof window === 'undefined') return null;
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },
  set: (session: UserSession) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    window.dispatchEvent(new Event('bluefit:auth-change'));
  },
  clear: () => {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(SESSION_KEY);
    window.dispatchEvent(new Event('bluefit:auth-change'));
  },
};

function getLocalDateISO(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });

  if (!res.ok) {
    let errorDetail = `HTTP ${res.status}`;
    try {
      const errJson = await res.json();
      errorDetail = errJson.detail || errJson.message || errorDetail;
    } catch {}
    throw new Error(errorDetail);
  }
  return res.json();
}

export const dashboardAPI = {
  // --- AUTH & FIRST-TIME SETUP ---
  login: async (role: 'CLIENT' | 'COACH', identifier: string, password: string) => {
    const user = await apiFetch<UserSession>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ role, identifier, password }),
    });
    authSession.set(user);
    return user;
  },

  completeFirstTimeSetup: async (payload: {
    userId: string;
    currentPassword: string;
    newPassword: string;
    [key: string]: any;
  }) => {
    const res = await apiFetch<{ message: string; user: UserSession }>('/auth/complete-setup', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    authSession.set(res.user);
    return res.user;
  },

  // --- ADMIN PROVISIONING & MANAGEMENT ---
  saveOnboarding: (payload: {
    name: string;
    role: 'CLIENT' | 'COACH' | 'ADMIN' | string;
    email: string;
    [key: string]: any;
  }) =>
    apiFetch<{
      message: string;
      userId: string;
      userCode: string;
      tempPassword: string;
      role: 'CLIENT' | 'COACH' | 'ADMIN';
      name: string;
    }>('/admin/onboarding', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getAllUsers: () => apiFetch<any[]>('/admin/users'),
  getAdminData: () => apiFetch<{ stats: any[] }>('/admin/dashboard/stats'),
  deleteUser: (userId: string) =>
    apiFetch<{ message: string }>(`/admin/users/${encodeURIComponent(userId)}`, {
      method: 'DELETE',
    }),
  assignCoach: (clientId: string, coachId: string) =>
    apiFetch<{ message: string; updated: any }>(
      `/admin/users/${encodeURIComponent(clientId)}/assign`,
      {
        method: 'PUT',
        body: JSON.stringify({ coachId }),
      }
    ),

  // --- COACH ---
  getCoachData: (coachId?: string) => {
    const activeId = authSession.get()?.PK || coachId || 'COACH#CHR001';
    return apiFetch<{ stats: any[]; recentActivity: any[] }>(
      `/coach/${encodeURIComponent(activeId)}/dashboard`
    );
  },
  getCoachClients: (coachId?: string) => {
    const activeId = authSession.get()?.PK || coachId || 'COACH#CHR001';
    return apiFetch<{ clients: CoachClient[] }>(
      `/coach/${encodeURIComponent(activeId)}/clients`
    );
  },
  getCoachTemplates: (coachId?: string) => {
    const activeId = authSession.get()?.PK || coachId || 'COACH#CHR001';
    return apiFetch<{ templates: any[] }>(
      `/coach/${encodeURIComponent(activeId)}/templates`
    );
  },
  createTemplate: (payload: any, coachId?: string) => {
    const activeId = authSession.get()?.PK || coachId || 'COACH#CHR001';
    return apiFetch<any>(`/coach/${encodeURIComponent(activeId)}/templates`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getTemplate: (templateId: string, coachId?: string) => {
    const activeId = authSession.get()?.PK || coachId;
    const q = activeId ? `?coachId=${encodeURIComponent(activeId)}` : '';
    return apiFetch<any>(`/coach/templates/${encodeURIComponent(templateId)}${q}`);
  },
  updateTemplate: (templateId: string, payload: any, coachId?: string) => {
    const activeId = authSession.get()?.PK || coachId;
    const q = activeId ? `?coachId=${encodeURIComponent(activeId)}` : '';
    return apiFetch<any>(`/coach/templates/${encodeURIComponent(templateId)}${q}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  // --- ATHLETE (CLIENT) ---
  getAthleteData: (athleteId?: string, date?: string) => {
    const activeId = authSession.get()?.PK || athleteId || 'CLIENT#CLS001';
    const d = date || getLocalDateISO();
    return apiFetch<{ date: string; todayTraining: any[] }>(
      `/athlete/${encodeURIComponent(activeId)}/dashboard?date=${encodeURIComponent(d)}`
    );
  },
  saveCheckin: (payload: {
    clientId?: string;
    weight: number;
    adherence: string;
    workoutQuality: string;
    waist?: number;
    notes?: string;
  }) => {
    const activeId = authSession.get()?.PK || payload.clientId || 'CLIENT#CLS001';
    return apiFetch<{ message: string; checkinId: string }>('/athlete/checkin', {
      method: 'POST',
      body: JSON.stringify({ ...payload, clientId: activeId }),
    });
  },
};