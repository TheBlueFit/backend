"use client";
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Save, Plus, GripVertical } from 'lucide-react';
import Link from 'next/link';
import { useParams } from 'next/navigation';

export default function TemplateClient() {
  const params = useParams<{ id: string }>();
  const [isLoading, setIsLoading] = useState(true);
  const [exercises, setExercises] = useState([
    { id: 1, name: 'Barbell Squat', sets: '3', reps: '8-10', rpe: '7' },
    { id: 2, name: 'Romanian Deadlift', sets: '3', reps: '10-12', rpe: '8' }
  ]);

  useEffect(() => {
    // Mocking an API call to fetch the specific template data using params.id
    setTimeout(() => setIsLoading(false), 500);
  }, [params.id]);

  return (
    <div className="container" style={{ maxWidth: '800px', paddingBottom: '80px' }}>
      
      {/* Top Navigation */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px' }}>
        <Link href="/coach/templates" style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-secondary)', textDecoration: 'none' }}>
          <ArrowLeft size={20} /> Back to Templates
        </Link>
        <button className="btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', fontSize: '13px', background: 'rgba(0, 226, 123, 0.15)', color: '#00E27B', border: '1px solid rgba(0, 226, 123, 0.4)' }}>
          <Save size={16} /> Save Changes
        </button>
      </div>

      <div className="app-card fade-in">
        <h1 className="animated-gradient-text" style={{ fontSize: '24px', margin: '0 0 8px 0' }}>Template Configuration</h1>
        <p className="label-text" style={{ color: 'var(--text-secondary)', textTransform: 'none', marginBottom: '32px' }}>
          Editing ID: {params.id}
        </p>

        {isLoading ? (
          <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text-secondary)' }}>Loading Configuration...</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            
            {/* Draggable Exercise List Mockup */}
            {exercises.map((ex, index) => (
              <div key={ex.id} style={{
                display: 'flex',
                alignItems: 'center',
                gap: '16px',
                background: 'rgba(255, 255, 255, 0.03)',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                padding: '16px',
                borderRadius: '12px'
              }}>
                <GripVertical size={20} color="var(--text-secondary)" style={{ cursor: 'grab' }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 'bold', color: '#fff', marginBottom: '4px' }}>{index + 1}. {ex.name}</div>
                  <div style={{ fontSize: '13px', color: 'var(--text-secondary)', display: 'flex', gap: '16px' }}>
                    <span>Sets: {ex.sets}</span>
                    <span>Reps: {ex.reps}</span>
                    <span>RPE: {ex.rpe}</span>
                  </div>
                </div>
              </div>
            ))}

            <button style={{
              width: '100%',
              padding: '16px',
              background: 'transparent',
              border: '1px dashed rgba(255, 255, 255, 0.2)',
              borderRadius: '12px',
              color: 'var(--text-secondary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              cursor: 'pointer',
              marginTop: '8px'
            }}>
              <Plus size={18} /> Add Exercise
            </button>

          </div>
        )}
      </div>
    </div>
  );
}